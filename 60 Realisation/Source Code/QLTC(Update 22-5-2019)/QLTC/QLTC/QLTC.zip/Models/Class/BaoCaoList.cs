﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLTC.Models
{
    public class BaoCaoList
    {
        public List<BaoCaoTemp> baoCao_List { get; set; }
    }
}