﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLTC.Models
{
    public class BaoCaoTemp
    {
        public string Ngay { get; set; }
        public string NgayFormat { get; set; }
        public double DoanhThu { get; set; }
        public int SoLuongTiec { get; set; }
    }
}