﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLTC.Models
{
    public class DSTiecCuoiList
    {
        public string tencodau { get; set; }
        public string tenchure { get; set; }
        public string tensanh { get; set; }
        public string ngay { get; set; }
        public string gio { get; set; }
        public string sdt { get; set; }
        public int soluongban { get; set; }
}
}