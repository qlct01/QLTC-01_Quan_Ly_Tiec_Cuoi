﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLTC.Models
{
    public class GiaDinhList
    {
        public List<gia_dinh> gia_dinhTK = new List<gia_dinh>();
    }
}