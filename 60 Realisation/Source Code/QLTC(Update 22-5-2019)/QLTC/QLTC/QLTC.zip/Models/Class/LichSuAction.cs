﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLTC.Models
{
    public class LichSuAction
    {
        public static int MaDatTiec = 0;

        public static string TenSanh = "";

        public static string TenCoDau = "";

        public static string TenChuRe = "";
    }
}