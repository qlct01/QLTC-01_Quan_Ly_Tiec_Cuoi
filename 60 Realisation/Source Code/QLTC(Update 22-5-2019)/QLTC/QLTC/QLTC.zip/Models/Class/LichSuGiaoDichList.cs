﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLTC.Models
{
    public class LichSuGiaoDichList
    {
        public List<LichSuGiaoDich> lichSu_List = new List<LichSuGiaoDich>();

        public List<ChiTietLichSu> ctLichSu_List = new List<ChiTietLichSu>();
    }
}