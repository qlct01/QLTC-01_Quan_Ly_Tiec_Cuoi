﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLTC.Models
{
    public class ModelList
    {
        public List<ca> caM { get; set; }
        public List<dich_vu> dich_vuM { get; set; }
        public List<mon_an> mon_anM { get; set; }
        public List<ds_sanh> ds_sanhsM { get; set; }
    }
}