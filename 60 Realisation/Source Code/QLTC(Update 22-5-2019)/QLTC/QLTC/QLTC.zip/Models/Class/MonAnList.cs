﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLTC.Models
{
    public class MonAnList
    {
        public List<mon_an> mon_anM { get; set; }
    }
}