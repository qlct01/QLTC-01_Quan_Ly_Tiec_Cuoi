﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLTC.Models
{
    public class Notice
    {
        public static bool enterSetSup = false;

        public static bool SetUpSuccess = false;

        public static bool CancelSetUp = false;

        public static bool updateSuccess = false;

        public static bool existAccount = false;

        public static bool signIn = false;

        public static bool logIn = false;

        public static bool adminLogIn = false;

        public static int i_S_C = 0;

        public static int i_L = 0;

        public static int i_S = 0;

        public static int i_U = 0;
        
        public static double tongDoanhThu = 0;

        public static int i_E = 0;
    }
}