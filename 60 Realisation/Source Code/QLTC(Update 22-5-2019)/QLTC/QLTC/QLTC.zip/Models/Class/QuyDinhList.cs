﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLTC.Models
{
    public class QuyDinhList
    {
        public List<tham_so> ds_thamsoM { get; set; }
    }
}