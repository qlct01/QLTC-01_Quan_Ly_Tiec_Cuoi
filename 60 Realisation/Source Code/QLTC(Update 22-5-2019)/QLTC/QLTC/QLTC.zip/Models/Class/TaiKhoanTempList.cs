﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLTC.Models
{
    public class TaiKhoanTempList
    {
        public gia_dinh tai_khoan_T { get; set; }
    }
}